"use strict";
import {initShaderProgram, loadTexture} from './openGLfuncs';
import {vsSource, fsSource} from './shaders';
import {initMesh} from './objs'
//import OBJ from "webgl-obj-loader";
import {sphere} from "./sphere";
import {model} from "./model";
import {pinkCar} from "./pinkCar2";
import Collision2D from "./collision";
import {platform} from "./platform";

let buffers;
let angleRotateCar = 0.0;
let zCarPos = 0.0, xCarPos = 0.0;
let currentPose = [[1.0,0.0,0.0],[2.0,0.0,0.0]];
let canLight2 = 1;

let GameObject = [];
let CarGameObject;

const OBJ = require('webgl-obj-loader');

window.onload = function main() {
    const canvas = document.querySelector("#gl_canvas");
    const gl = canvas.getContext("webgl2");// Получаем контекст webgl2

    if (gl === null) {
        alert("Unable to initialize WebGL. Your browser or machine may not support it.");// Обработка ошибок
        return;
    }
    
    gl.viewport(0, 0, gl.canvas.width, gl.canvas.height);// Устанавливаем размер вьюпорта  
    gl.enable(gl.DEPTH_TEST);// Включаем z-buffer
    
    const programInfo = initProgramInfo(gl);

    //CreateGameObject
    CarGameObject = new Collision2D(0.0,0.0,0.11);
    GameObject[0] = new Collision2D(currentPose[1][0],currentPose[1][2],0.05);
    buffers = [initMesh(gl,new OBJ.Mesh(sphere),[0.7,0.1,0.6,1.0],"texture.png"),
        initMesh(gl, new OBJ.Mesh(model),[0.2,0.3,0.7,1.0]),
        initMesh(gl, new OBJ.Mesh(platform),[1.0,1.0,1.0,1.0])];// Инициализируем буфер
   //SetStartPosition
    buffers[0].setTranslateScale([0.0,0.0,0],[0.1,0.1,0.1],angleRotateCar);
    buffers[1].setTranslateScale(currentPose[1],[0.1,0.1,0.1],0);
    buffers[2].setTranslateScale([0.0,0.0,0.0],[0.1,1.0,0.1],0);



    window.onkeydown = (e) => {
        drawScene(gl, programInfo, buffers);
    }
    drawScene(gl, programInfo, buffers);
}


function initProgramInfo(gl) {
    const shaderProgram = initShaderProgram(gl, vsSource, fsSource);// Создаём шейдерную программу
    return {
        program: shaderProgram,// Сама программа
        attribLocations: {
            vertexPosition: gl.getAttribLocation(shaderProgram, 'avertexPosition'),
            normalPosition: gl.getAttribLocation(shaderProgram, 'anormalPosition'),
            textureCoords: gl.getAttribLocation(shaderProgram, 'textureCoords'),

            normalPosition2: gl.getAttribLocation(shaderProgram, 'v2'),
            textureCoords2: gl.getAttribLocation(shaderProgram, 't2'),
            
            normalPosition2: gl.getAttribLocation(shaderProgram, 'v3'),
            textureCoords2: gl.getAttribLocation(shaderProgram, 't3'),
        },
        uniformLocations: {
            color: gl.getUniformLocation(shaderProgram, 'uColor'),
            modelViewMatrix: gl.getUniformLocation(shaderProgram, 'uModelViewMatrix'),
            viewMatrix: gl.getUniformLocation(shaderProgram, 'uViewMatrix'),
            projectionMatrix: gl.getUniformLocation(shaderProgram, 'uProjectionMatrix'),
            normalMatrix: gl.getUniformLocation(shaderProgram, 'uNormalMatrix'),
            //light
            lightPosition: gl.getUniformLocation(shaderProgram, 'light.position'),//!!!!!!!!!!!!!!!!!!!!direction
            lightAmbient: gl.getUniformLocation(shaderProgram, 'light.ambient'),
            lightDiffuse: gl.getUniformLocation(shaderProgram, 'light.diffuse'),
            lightSpecular: gl.getUniformLocation(shaderProgram, 'light.specular'),
            //light2
            lightPosition2: gl.getUniformLocation(shaderProgram, 'light2.position'),//!!!!!!!!!!!!!!!!!!!!direction
            lightAmbient2: gl.getUniformLocation(shaderProgram, 'light2.ambient'),
            lightDiffuse2: gl.getUniformLocation(shaderProgram, 'light2.diffuse'),
            lightSpecular2: gl.getUniformLocation(shaderProgram, 'light2.specular'),
            lightOn2: gl.getUniformLocation(shaderProgram, 'light2.on'),
            //SpotLight
            lightDirSpot: gl.getUniformLocation(shaderProgram, `spotLight.direction`),
            lightAttenSpot: gl.getUniformLocation(shaderProgram,`spotLight.attenuation`),
            lightSpecSpot: gl.getUniformLocation(shaderProgram,`spotLight.specular`),
            lightDiffSpot: gl.getUniformLocation(shaderProgram,`spotLight.diffuse`),
            lightAmbientSpot: gl.getUniformLocation(shaderProgram,`spotLight.ambient`),
            lightPosSpot: gl.getUniformLocation(shaderProgram,`spotLight.position`),
            lightExpSpot: gl.getUniformLocation(shaderProgram,`spotLight.exp`),
            lightCutSpot: gl.getUniformLocation(shaderProgram,`spotLight.cutoff`),
            //params
            viewPosition: gl.getUniformLocation(shaderProgram, 'params.viewPosition'),//4 3 3
            uSampler: gl.getUniformLocation(shaderProgram,'uSampler'),
        },
        textures: {
            textureMaterial: loadTexture(gl, document.getElementById("orange").src),
            textureMaterial2: loadTexture(gl,document.getElementById("carTexture").src),
        }
    };
}


function setupLights(gl, {uniformLocations}) {
    gl.uniform3fv(uniformLocations.lightPosition, [0.5, 1.2, 2.0]);
    gl.uniform3fv(uniformLocations.lightAmbient, [0.1, 0.1, 0.1]);
    gl.uniform3fv(uniformLocations.lightDiffuse, [0.7, 0.7, 0.7]);
    gl.uniform3fv(uniformLocations.lightSpecular, [1.0, 1.0, 1.0]);

    gl.uniform1f(uniformLocations.lightOn2,canLight2);
    gl.uniform3fv(uniformLocations.lightPosition2, [100.0, 0.0, 0.0]);
    gl.uniform3fv(uniformLocations.lightAmbient2, [1.0, 1.0, 1.0]);
    gl.uniform3fv(uniformLocations.lightDiffuse2, [0.7, 0.7, 0.7]);
    gl.uniform3fv(uniformLocations.lightSpecular2, [1.0, 1.0, 1.0]);

    gl.uniform4fv(uniformLocations.lightPosSpot,[0.0,1.0,0.0,0.0]);
    gl.uniform4fv(uniformLocations.lightAmbientSpot,[0.1, 0.1, 0.1, 1.0]);
    gl.uniform4fv(uniformLocations.lightDiffSpot,[2.7, 2.7, 2.7, 1.0]);
    gl.uniform4fv(uniformLocations.lightSpecSpot,[1.0, 1.0, 1.0, 1.0]);
    gl.uniform3fv(uniformLocations.lightAttenSpot,[0.7, 0.7, 0.7]);
    gl.uniform3fv(uniformLocations.lightDirSpot,[0.0, -1.0, 0.0]);
    gl.uniform1f(uniformLocations.lightCutSpot,1);
    gl.uniform1f(uniformLocations.lightExpSpot,1);


    gl.uniform3fv(uniformLocations.viewPosition, [4.0, 3.0, 3.0]);
}

function setupCarLight(gl,{uniformLocations},carLightPos)
{

}

function drawScene(gl, programInfo, buffers) {
    gl.clearColor(0.0, 0.0, 0.0, 1.0);// Чистим экран
    gl.clearDepth(1.0);
    gl.depthFunc(gl.LEQUAL);
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);

    gl.useProgram(programInfo.program);// Устанавливаем используемую программу
    setupLights(gl,programInfo);
    const fieldOfView = 45 * Math.PI / 180;   // in radians
    const projectionMatrix = mat4.create();
    mat4.perspective(projectionMatrix, fieldOfView,  gl.canvas.clientWidth / gl.canvas.clientHeight, 0.1, 100.0);
    gl.uniformMatrix4fv(programInfo.uniformLocations.projectionMatrix, false, projectionMatrix);

    gl.activeTexture(gl.TEXTURE1);
    gl.bindTexture(gl.TEXTURE_2D, programInfo.textures.textureMaterial2);
    gl.uniform1i(programInfo.uniformLocations.uSampler, 1);

    buffers[0].setTranslateScale([xCarPos,0.0,zCarPos],[0.1,0.1,0.1],angleRotateCar, "texture.png");
    buffers[0].draw(gl, programInfo);
    gl.activeTexture(gl.TEXTURE0);
    gl.bindTexture(gl.TEXTURE_2D, programInfo.textures.textureMaterial);
    gl.uniform1i(programInfo.uniformLocations.uSampler, 0);
    buffers[1].setTranslateScale(currentPose[1],[0.5,0.5,0.5],0.0);
    buffers[1].draw(gl, programInfo);

    buffers[2].draw(gl, programInfo);
}

addEventListener("keydown", alertKey);

function CanMove(car)
{
    let can = true;
    GameObject.forEach(object => {
        if(car.intersects(object)){
            //console.log("eeeeeeeee");
            can = false;
            return;
        }
    })
    return can;
}

function alertKey(e) {
    let futureCar = new Collision2D(CarGameObject.x,CarGameObject.y,CarGameObject.r);
   if(e.key == "ArrowLeft") {
       futureCar.x += 0.05*Math.cos(angleRotateCar+ 0.035);
       futureCar.y += -0.05*Math.sin(angleRotateCar+0.035);
       if (CanMove(futureCar)) {
           angleRotateCar += 0.035;
           xCarPos += 0.05 * Math.cos(angleRotateCar);
           zCarPos += -0.05 * Math.sin(angleRotateCar);
       }
   }
   if(e.key == "ArrowRight") {
       futureCar.x += 0.05*Math.cos(angleRotateCar-0.035);
       futureCar.y += -0.05*Math.sin(angleRotateCar-0.035);
       if (CanMove(futureCar)) {
           angleRotateCar -= 0.035;
           xCarPos += 0.05 * Math.cos(angleRotateCar);
           zCarPos += -0.05 * Math.sin(angleRotateCar);
       }
   }
    if(e.key == "ArrowUp") {
        futureCar.x += 0.05*Math.cos(angleRotateCar);
        futureCar.y += -0.05*Math.sin(angleRotateCar);
        if(CanMove(futureCar)) {
            xCarPos += 0.05 * Math.cos(angleRotateCar);
            zCarPos += -0.05 * Math.sin(angleRotateCar);
        }
    }
    if(e.key == "ArrowDown") {
        futureCar.x -= 0.05*Math.cos(angleRotateCar);
        futureCar.y -= -0.05*Math.sin(angleRotateCar);
        if(CanMove(futureCar)) {
            xCarPos -= 0.05 * Math.cos(angleRotateCar);
            zCarPos -= -0.05 * Math.sin(angleRotateCar);
        }
    }
    if(e.key == "L") {
        if (canLight2 > 0) {
            canLight2 = 0;
        } else {
            canLight2 = 1;
        }
        console.log(canLight2);
    }
    CarGameObject.x = xCarPos;
    CarGameObject.y = zCarPos;
    CarGameObject.rotateLight(angleRotateCar);
}